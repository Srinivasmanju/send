import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  uname:String='intercalling';
  city:String='banglore';
  name='LTE';
  year='2000';
  
  
  
  source:any='assets/banklogoo.png';
  high:number=40;
  width:number=200;
  
  
  carval:number=0;
  homeval:number=0;
  personalval:number=0;
  constructor() { }

  ngOnInit(): void {
  }
  flag:boolean=false;
  
      
} 
