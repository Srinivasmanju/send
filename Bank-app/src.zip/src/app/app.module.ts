import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FormComponent } from './form/form.component';
import { Person1Component } from './person1/person1.component';

import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { Person2Component } from './person2/person2.component';
import { CarloanComponent } from './carloan/carloan.component';
import { HomeloanComponent } from './homeloan/homeloan.component';
import { PersonalloanComponent } from './personalloan/personalloan.component';
import { AboutComponent } from './about/about.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FormComponent,
    LoginComponent,
    Person1Component,
    Person2Component,
    CarloanComponent,
    HomeloanComponent,
    PersonalloanComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
