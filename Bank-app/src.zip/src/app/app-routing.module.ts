import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CarloanComponent } from './carloan/carloan.component';

import { HomeloanComponent } from './homeloan/homeloan.component';
import { Person1Component } from './person1/person1.component';
import { PersonalloanComponent } from './personalloan/personalloan.component';

const routes: Routes = [
 
  {path:'homeloan',component:HomeloanComponent},
  {path:'ploan',component:PersonalloanComponent},
  {path:'carloan',component:CarloanComponent},
  {path:'about',component:AboutComponent},
  {path:'chat',component:Person1Component}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
