import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homeloan',
  templateUrl: './homeloan.component.html',
  styleUrls: ['./homeloan.component.css']
})
export class HomeloanComponent implements OnInit {

  uname:String='intercalling';
  city:String='banglore';
  name='LTE';
  year='2000';
  
  
  
  source:any='assets/banklogoo.png';
  high:number=40;
  width:number=200;
  
  
  carval:number=0;
  homeval:number=0;
  personalval:number=0;
  currency: number=0;

  
  constructor() { }
  
  
  
  ngOnInit(): void {
  }
  getDetails(){
  return `Hii this is ${this.name} and city is ${this.city}`;
  }
  rightp:string="right";
  
  
  home(value :any){
  this.homeval= Math.round(value*0.10);
  console.log(this.homeval);
  }
  car(value :any){
  this.carval=Math.round(value*0.07);
  console.log(this.carval);
  }
  personal(value :any){
  this.personalval=Math.round(value*0.05);
  console.log(this.personalval);
  }
  flag:boolean=false;
  flag1:boolean=false;
  json=[{'fname':'rahul','lname':'rahul','age':20,'email':"sssss"},
  {'fname':'sri','lname':'rahul','age':21,'email':"sssss"},
  {'fname':'ram','lname':'rahul','age':25,'email':"ssssss"},
  {'fname':'raju','lname':'rahul','age':29,'email':"hhhh"}];
  
  sendData(value:String){
    this.json.toString();
    }
    
    addjson(value:any){



      this.json.push(value);
      }
      change()
      {
        if(this.flag)
        {
          this.flag=!this.flag;
        }
        else{
          this.flag=!this.flag;
        }
      }
      changes()
      {
        if(this.flag)
        {
          this.flag=!this.flag;
        }
        else{
          this.flag=!this.flag;
        }
      }
      changes1()
      {
        if(this.flag1)
        {
          this.flag1=!this.flag1;
        }
        else{
          this.flag1=!this.flag1;
        }
      }
}
